﻿using Abp.Application.Services;
using LMS.MultiTenancy.Dto;

namespace LMS.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

